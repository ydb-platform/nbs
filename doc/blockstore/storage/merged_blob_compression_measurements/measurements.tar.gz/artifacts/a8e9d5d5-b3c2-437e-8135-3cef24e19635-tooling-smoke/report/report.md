# Merged blob compression measurements

Release gates are not implied by this report.

| Run | Mode | Ratio | Savings % | Compressed live fraction |
| --- | --- | ---: | ---: | ---: |

Raw and per-repeat CPU/latency/queue/counter values are in report.json.

* Live DescribeBlocks inventory excludes unreferenced checkpoint/garbage blobs.
* A storage claim requires an isolated disk without checkpoints and post-GC proof.
* NIC counters include all namespace traffic; select process/route boundaries separately.
* Ten physical-core release repeats and all production CPU classes remain required.
* CPU/latency/memory rollout budgets require a reviewed decision based on these samples.
